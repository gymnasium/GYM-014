"use strict";
console.log('Beginning Pattern Lab Node Gulp postinstall...');

//call the core library postinstall
var patternlab = require('patternlab-node/core/scripts/postinstall');
