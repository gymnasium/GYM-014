---
title: Hero Image
---

Image within the hero.