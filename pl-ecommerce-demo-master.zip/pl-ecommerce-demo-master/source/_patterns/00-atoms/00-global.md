The global category defines visual elements such as color, font families, and motion. While not technically UI components, these elements are critical to document in the pattern library.
