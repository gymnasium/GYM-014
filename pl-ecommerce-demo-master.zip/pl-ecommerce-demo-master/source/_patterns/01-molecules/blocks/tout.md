---
title: Tout
---

The tout block is a lockup of an image with a title overlay, serving as a link to another page.

Usage: Typically found on homepages and marketing pages.
