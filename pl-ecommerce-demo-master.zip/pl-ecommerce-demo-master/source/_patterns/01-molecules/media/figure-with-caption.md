---
title: Figure with Caption
---

[Insert description here]